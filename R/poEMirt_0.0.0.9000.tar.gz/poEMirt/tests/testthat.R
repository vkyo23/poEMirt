library(testthat)
library(poEMirt)

test_check("poEMirt")